#! /bin/sh

export LC_ALL="en_US.UTF-8"

# Working directory
SKETCH_DIR="${0%/*}"

# Start from our working directory
cd "$SKETCH_DIR" || exit

# Check whether nickel is running
export FROM_NICKEL=0
pgrep -f nickel > /dev/null && FROM_NICKEL=1

if [ "$FROM_NICKEL" -eq 1 ]; then
	# Siphon a few things from nickel's environment
	eval "$(xargs -n 1 -0 < /proc/$(pidof nickel)/environ | grep -e DBUS_SESSION_BUS_ADDRESS -e WIFI_MODULE -e PLATFORM -e WIFI_MODULE_PATH -e INTERFACE -e PRODUCT 2> /dev/null)"
	export DBUS_SESSION_BUS_ADDRESS WIFI_MODULE PLATFORM WIFI_MODULE_PATH INTERFACE PRODUCT
	# Flush the disks. Might help avoid trashing nickel's DB...
	sleep 1; sync
	# Stop kobo software because it's running
	killall nickel hindenburg sickel fickel fmon > /dev/null 2>&1
fi

# Remount the SD card RW if it's inserted and currently RO
if awk '$4~/(^|,)ro($|,)/' /proc/mounts | grep -q ' /mnt/sd '; then
	mount -o remount,rw /mnt/sd
fi

# Workaround 32-bit without KSM (KSM is indicated by $ksmroot being set)
if [ -z "$ksmroot" ]; then
	CUR_ROTATE="$(cat "/sys/class/graphics/fb0/rotate")"
	FB_BPP=$(cat /sys/class/graphics/fb0/bits_per_pixel)
	[ "$FB_BPP" -gt 16 ] && /usr/sbin/fbset -depth 16
	# This suffices on normal devices, but H2O is stupid and sets the opposite
	echo "$CUR_ROTATE" >"/sys/class/graphics/fb0/rotate"
	# This therefore turns it around on H2O and merely innocently repeats on
	# sane devices
	cat "/sys/class/graphics/fb0/rotate" >"/sys/class/graphics/fb0/rotate"
fi

./sketch > crash.log 2>&1
RESULT=$?

# Workaround 32-bit without KSM (KSM is indicated by $ksmroot being set)
if [ -z "$ksmroot" ]; then
	# Back to default depth in framebuffer.
	[ "$FB_BPP" -gt 16 ] && /usr/sbin/fbset -depth "$FB_BPP"
fi

if [ "$FROM_NICKEL" -eq 1 ]; then
	# Start kobo software because it was running before sketch
	./nickel.sh &
else
	# If we were called from advboot then we must reboot to go to the menu
	if ! pgrep -f kbmenu > /dev/null; then
		/sbin/reboot
	fi
fi

return $RESULT
